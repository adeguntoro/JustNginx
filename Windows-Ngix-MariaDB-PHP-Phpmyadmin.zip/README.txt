#########################
How to start nginx ?
just double click nginx.exe


#########################
How to start php-cgi ?
open CMD and go to PHP folder. Then type "php-cgi.exe -b 127.0.0.1:9000"


#########################
how to start mysql/mariadb
open CMD and go to PHP folder > bin and then type "mysqld.exe"


##########################
Autoindex in nginx already turn on, no need to setting anymore.


#####################
Download mariadb and extract into mariadb folder


#######################
download phpmyadmin and extract into html > phpmyadmin


#######################
download php extract into php folder